import{g as e,bH as a,bV as n,r as s}from"./ZetUEUt2.js";const i=e({__name:"index",setup(t){return a(),n(),s(0),(o,r)=>null}});export{i as default};
